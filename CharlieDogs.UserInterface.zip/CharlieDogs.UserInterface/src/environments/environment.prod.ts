export const environment = {
  production: true,
  serviceUrl: "http://localhost:50790/"
};
