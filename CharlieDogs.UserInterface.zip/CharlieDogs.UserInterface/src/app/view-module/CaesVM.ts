export class caesVM {
  idCachorro: number;
  descricao: string;
  dataNascimento: Date;
  peso: number;
  porte: number;
  corPredominante: number;
  preco: number;
  status: boolean;
  quantidade: number;
  racaDescricao: string;
  imagem: string;
}
